		

				<!-- Header -->
				<div class="template-header template-header-background template-header-background-1">
<?php
		Template::includeTemplateHeaderTop();
		Template::includeTemplateHeaderBottom('Blog small image',array(array(Template::getPageURL('home',false),'Home'),array('#','Blog small image')));
?>
				
				</div>

				<!-- Content -->
				<div class="template-content">

					<!-- Main -->
					<div class="template-section template-main">
					
						<!-- Layout -->
						<div class="template-content-layout template-content-layout-sidebar-right template-clear-fix">

							<!-- Left column -->
							<div class="template-content-layout-column-left">
								<?php Template::includeFile('blog-small-image'); ?>
							</div>

							<!-- Right column -->
							<div class="template-content-layout-column-right">
								<?php Template::includeFile('sidebar-blog'); ?>
							</div>

						</div>
						
					</div>
					
					<!-- Google Maps -->
					<div class="template-section template-section-padding-reset template-clear-fix">
						<?php Template::includeFile('google-map-1'); ?>
					</div>
					
				</div>