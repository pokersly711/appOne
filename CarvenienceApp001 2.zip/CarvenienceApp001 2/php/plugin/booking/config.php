<?php
		define('BOOKING_FORM_NAME','QuanticaLabs@gmail.com');
		define('BOOKING_FORM_EMAIL','quanticalabs@gmail.com');

		define('BOOKING_FORM_SMTP_HOST','');
		define('BOOKING_FORM_SMTP_USER','');
		define('BOOKING_FORM_SMTP_PORT','');
		define('BOOKING_FORM_SMTP_SECURE','');
		define('BOOKING_FORM_SMTP_PASSWORD','');
		
		define('BOOKING_FORM_SUBJECT','Auto Spa - Car Wash Auto Detail Template: Booking');
		
		define('BOOKING_FORM_MSG_INVALID_DATA_FIRST_NAME','Please enter your first name.');
		define('BOOKING_FORM_MSG_INVALID_DATA_SECOND_NAME','Please enter your second name.');
		define('BOOKING_FORM_MSG_INVALID_DATA_EMAIL','Please enter valid e-mail.');
		define('BOOKING_FORM_MSG_INVALID_DATA_PHONE','Please enter your phone.');
		define('BOOKING_FORM_MSG_INVALID_DATA_DATE','Please enter valid date and time of booking.');
		define('BOOKING_FORM_MSG_INVALID_DATA_MESSAGE','Please enter your message.');

		define('BOOKING_FORM_MSG_SEND_OK','Thank you for order.');
		define('BOOKING_FORM_MSG_SEND_ERROR','Sorry, we can\'t send this order.');