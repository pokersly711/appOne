<?php
		define('NEWSLETTER_FORM_API_KEY','');
		define('NEWSLETTER_FORM_LIST_ID','');
		
		define('NEWSLETTER_FORM_MSG_INVALID_DATA_EMAIL','Please enter valid e-mail.');
		
		define('NEWSLETTER_FORM_MSG_SEND_OK','Your e-mail address has been added.');
		define('NEWSLETTER_FORM_MSG_SEND_ERROR','Sorry, we can\'t add this e-mail address.');