<?php
		define('CONTACT_FORM_NAME','QuanticaLabs@gmail.com');
		define('CONTACT_FORM_EMAIL','quanticalabs@gmail.com');

		define('CONTACT_FORM_SMTP_HOST','');
		define('CONTACT_FORM_SMTP_USER','');
		define('CONTACT_FORM_SMTP_PORT','');
		define('CONTACT_FORM_SMTP_SECURE','');
		define('CONTACT_FORM_SMTP_PASSWORD','');
		
		define('CONTACT_FORM_SUBJECT','Auto Spa - Car Wash Auto Detail Template: Contact');

		define('CONTACT_FORM_MSG_INVALID_DATA_NAME','Please enter your name.');
		define('CONTACT_FORM_MSG_INVALID_DATA_EMAIL','Please enter valid e-mail.');
		define('CONTACT_FORM_MSG_INVALID_DATA_MESSAGE','Please enter your message.');

		define('CONTACT_FORM_MSG_SEND_OK','Thank you for contacting us.');
		define('CONTACT_FORM_MSG_SEND_ERROR','Sorry, we can\'t send this message.');
		
